#points to commands that help request info/actions using the gateway
#note, no need for importing GuildParse because resp is a Resp object (resp.parsed... does the trick)
#also, no need for importing GuildRequest because gatewayobj has that (self.gatewayobj.request... does the trick)

import time, requests
import copy
import re
from ...utils.permissions import PERMS, Permissions
from ...logger import *

class GuildCombo(object):
    __slots__ = ['gatewayobj']
    def __init__(self, gatewayobj):
        self.gatewayobj = gatewayobj

    #fetchMembers helper function
    def reformat_member(self, memberdata, keep=[]): #memberdata comes in as a dict and leaves as a tuple (userID, memberdatareformatted). This is done to easily prevent duplicates in the member list when fetching.
        allProperties = ['pending', 'deaf', 'hoisted_role', 'presence', 'joined_at', 'public_flags', 'username', 'avatar', 'discriminator', 'premium_since', 'roles', 'is_pending', 'mute', 'nick', 'bot', 'communication_disabled_until']
        if keep == None:
            remove = allProperties
        elif keep == "all":
            remove = []
        elif isinstance(keep, list) or isinstance(keep, tuple):
            remove = list(set(allProperties) - set(keep))
        elif isinstance(keep, str):
            remove = [i for i in allProperties if i!=keep]
        memberproperties = copy.deepcopy(memberdata['member']) if 'member' in memberdata else copy.deepcopy(memberdata)
        userdata = memberproperties.pop('user', {})
        userID = userdata.pop('id', {})
        memberproperties.update(userdata)
        #filtering/removing
        for r in remove:
            if r in memberproperties:
                del memberproperties[r]
        return userID, memberproperties

    #fetchMembers helper function
    def rangeCorrector(self, ranges): #just adds [0,99] at the beginning
        if [0,99] not in ranges:
            ranges.insert(0, [0,99])
        return ranges

    #fetchMembers helper function
    def getIndex(self, guild_id):
        return self.gatewayobj.memberFetchingStatus[guild_id][1]

    #fetchMembers helper function
    def getRanges(self, index, multiplier, memberCount):
        initialNum = int(index*multiplier)
        rangesList = [[initialNum, initialNum+99]]
        if memberCount > initialNum+99:
            rangesList.append([initialNum+100, initialNum+199])
        return self.rangeCorrector(rangesList)

    #fetchMembers helper function
    def updateCurrent(self, guild_id):
        if not self.gatewayobj.finishedMemberFetching(guild_id): #yep still gotta check for this
            self.gatewayobj.memberFetchingStatus[guild_id][1] = self.gatewayobj.memberFetchingStatus[guild_id][0]+1

    #fetchMembers helper function
    def updatePrevious(self, guild_id):
        if not self.gatewayobj.finishedMemberFetching(guild_id):
            self.gatewayobj.memberFetchingStatus[guild_id][0] = self.gatewayobj.memberFetchingStatus[guild_id][1]

    #todo: make channel_id optional (make a helper method to find the "optimal" channel). Also...maybe rewrite fetchMembers to simply code a bit??
    def fetchMembers(self, resp, guild_id, channel_id, method, keep, considerUpdates, startIndex, stopIndex, reset, wait): #process is a little simpler than it looks. Keep in mind that there's no actual api endpoint to get members so this is a bit hacky. However, the method used below mimics how the official client loads the member list.
        if self.gatewayobj.READY:
            if self.gatewayobj.memberFetchingStatus.get(guild_id) == None: #request for lazy request
                self.gatewayobj.memberFetchingStatus[guild_id] = [startIndex, startIndex] #format is [previous index, current index]. This format is useful for the wait parameter.
                if not self.gatewayobj.session.guild(guild_id).hasMembers and reset:
                    self.gatewayobj.session.guild(guild_id).resetMembers() #reset
                if len(self.gatewayobj.memberFetchingStatus["first"]) == 0:
                    self.gatewayobj.memberFetchingStatus["first"] = [guild_id]
                    self.gatewayobj.request.lazyGuild(guild_id, {channel_id: [[0,99]]}, typing=True, threads=False, activities=True, members=[])
                else:
                    self.gatewayobj.request.lazyGuild(guild_id, {channel_id: [[0,99]]}, typing=True, activities=True)
            if self.gatewayobj.memberFetchingStatus.get(guild_id) != None and not self.gatewayobj.finishedMemberFetching(guild_id): #proceed with lazy requests
                index = self.getIndex(guild_id) #index always has the current value
                endFetching = False
                #find multiplier (this dictates the way the member list requested for)
                if method == "overlap": multiplier = 100
                elif method == "no overlap": multiplier = 200
                elif isinstance(method, int): multiplier = method
                elif isinstance(method, list) or isinstance(method, tuple): 
                    if index<len(method):
                        multiplier = method[index]
                    else:
                        endFetching = True #ends fetching right after resp parsed
                ranges = self.getRanges(index, multiplier, self.gatewayobj.session.guild(guild_id).memberCount) if not endFetching else [[0],[0]]
                #0th lazy request (separated from the rest because this happens "first")
                if index == startIndex and not self.gatewayobj.session.guild(guild_id).unavailable:
                    self.updateCurrent(guild_id) #current = previous+1
                    if wait!=None: time.sleep(wait)
                    self.gatewayobj.request.lazyGuild(guild_id, {channel_id: ranges})
                if resp.event.guild_member_list:
                    parsed = resp.parsed.guild_member_list_update()
                    if parsed['guild_id'] == guild_id and ('SYNC' in parsed['types'] or 'UPDATE' in parsed['types']):
                        endFetching = False
                        for ind,i in enumerate(parsed['types']):
                            if i == 'SYNC':
                                if len(parsed['updates'][ind]) == 0 and parsed['locations'][ind] in ranges[1:]: #checks if theres nothing in the SYNC data
                                    endFetching = True
                                    break
                                for item in parsed['updates'][ind]:
                                    if 'member' in item:
                                        member_id, member_properties = self.reformat_member(item, keep=keep)
                                        self.gatewayobj.session.guild(guild_id).updateOneMember(member_id, member_properties)
                                        Logger.log('[gateway] [fetchMembers] <SYNC> updated member '+member_id, None, self.gatewayobj.log)
                                if not self.gatewayobj.finishedMemberFetching(guild_id) and (index-self.gatewayobj.memberFetchingStatus[guild_id][0])==1:
                                    if wait!=None: time.sleep(wait)
                                    self.updatePrevious(guild_id) #previous = current
                            elif i == 'UPDATE' and considerUpdates: #this really only becomes useful for large guilds (because fetching members can take a quite some time for those guilds)
                                for key in parsed['updates'][ind]:
                                    if key == 'member':
                                        member_id, member_properties = self.reformat_member(parsed['updates'][ind][key], keep=keep)
                                        self.gatewayobj.session.guild(guild_id).updateOneMember(member_id, member_properties)
                                        Logger.log('[gateway] [fetchMembers] <UPDATE> updated member '+member_id, None, self.gatewayobj.log)
                            elif i == 'INVALIDATE':
                                if parsed['locations'][ind] in ranges or parsed['member_count'] == 0:
                                    endFetching = True
                                    break
                        numFetched = len(self.gatewayobj.session.guild(guild_id).members)
                        roundedUpFetched = numFetched-(numFetched%-100) #https://stackoverflow.com/a/14092788/14776493
                        if ranges==[[0],[0]] or index>=stopIndex or roundedUpFetched>=self.gatewayobj.session.guild(guild_id).memberCount or endFetching or ranges[1][0]+100>self.gatewayobj.session.guild(guild_id).memberCount: #putting whats most likely to happen first
                            self.gatewayobj.memberFetchingStatus[guild_id] = "done"
                            self.gatewayobj.removeCommand(
                                {
                                    "function": self.fetchMembers,
                                    "params": {
                                        "guild_id": guild_id,
                                        "channel_id": channel_id,
                                        "method": method,
                                        "keep": keep,
                                        "considerUpdates": considerUpdates,
                                        "startIndex": startIndex,
                                        "stopIndex": stopIndex,
                                        "reset": reset,
                                        "wait": wait
                                    },
                                }
                            ) #it's alright if you get a "not found in _after_message_hooks" error log. That's not an error for this situation.
                        elif not self.gatewayobj.finishedMemberFetching(guild_id) and index==self.gatewayobj.memberFetchingStatus[guild_id][0]:
                            self.updateCurrent(guild_id) #current = previous + 1
                            self.gatewayobj.request.lazyGuild(guild_id, {channel_id: ranges})


    #helper method for subscribeToGuildEvents
    def get_token_channels(self, guildID, token):
                
                headers = {
                'authority': 'discord.com',
                'accept': '*/*',
                'accept-language': 'en-US,en;q=0.9,pt-BR;q=0.8,pt;q=0.7,mn;q=0.6',
                'authorization': token,
                'cache-control': 'no-cache',
                'content-type': 'application/json',
                # Requests sorts cookies= alphabetically
                # 'cookie': '__dcfduid=9d2e50d43e0a11ed8a17e636b754be3a; __sdcfduid=9d2e50d43e0a11ed8a17e636b754be3a1b3a70b875bfee7709c9f86dc78a03f4ef43932d74295664edd061beff1bb9a7; _ga=GA1.2.241072284.1664977992; OptanonConsent=isIABGlobal=false&datestamp=Wed+Oct+05+2022+11%3A29%3A52+GMT-0300+(Brasilia+Standard+Time)&version=6.33.0&hosts=&consentId=f1f1ee1f-88df-44ae-af2e-15e379ffd247&interactionCount=1&landingPath=https%3A%2F%2Fdiscord.com%2F&groups=C0001%3A1%2CC0002%3A0%2CC0003%3A0; __stripe_mid=442d4cbc-481c-4363-b564-d5b04d217b5e1152b0; __cfruid=0e0eb28533d661290032b855b45d5080ecfb0227-1666737614; locale=ro; __cf_bm=Uv0qicvCGyjWIzTMnVmwFvsFfjOMZD_n4FVF_ankIcI-1666740905-0-ATJ/Ewr3nZImoseRDddrvQbGcGtsnSr3nZ0ONaXiGNivcRaImH7BUGWr3oi+Y19/mSye2oah4SBaCl1DZR5LKOcGR5RHBq1fVDW9ZHVVJInXmHuIO46i/3hbWA6Ogeiuow==',
                'pragma': 'no-cache',
                'referer': 'https://discord.com/channels/@me',
                'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
                'x-debug-options': 'bugReporterEnabled',
                'x-discord-locale': 'ro',
                'x-super-properties': 'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEwNi4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTA2LjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiJodHRwczovL2Rpc2NvcmQuY29tL2NoYW5uZWxzL0BtZSIsInJlZmVycmluZ19kb21haW4iOiJkaXNjb3JkLmNvbSIsInJlZmVycmVyX2N1cnJlbnQiOiIiLCJyZWZlcnJpbmdfZG9tYWluX2N1cnJlbnQiOiIiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfYnVpbGRfbnVtYmVyIjoxNTQxODYsImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9',
            }

                response = requests.get(f'https://discord.com/api/v9/guilds/{guildID}/channels', headers=headers)
                return response.json()
    
    def findVisibleChannels(self, guildID, types, findFirst, token):
        channelIDs = []
        if types == "all":
            types = ['guild_text', 'dm', 'guild_voice', 'group_dm', 'guild_category', 'guild_news', 'guild_store', 'guild_news_thread', 'guild_public_thread', 'guild_private_thread', 'guild_stage_voice']
        s = self.gatewayobj.session
        channels = self.get_token_channels(guildID, token)
        for channel in channels:
                    if findFirst:
                        return [channel['id']]
                    else:
                        channelIDs.append(channel['id'])
        return channelIDs

    def subscribeToGuildEvents(self, onlyLarge, wait, guildIDs, token):
        if self.gatewayobj.READY:
            s = self.gatewayobj.session
            first = {"channel_ranges":{}, "typing":True, "threads":True, "activities":True, "members":[], "thread_member_lists":[]}
            rest = {"channel_ranges":{}, "typing":True, "activities":True, "threads":True}
            for guildID in guildIDs:
                #skip if needed (onlyLarge checking)
                if onlyLarge and not (s.guild(guildID).unavailable or s.guild(guildID).large):
                    continue
                #op 14 field construction
                op14fields = {"guild_id":guildID}
                if guildID == guildIDs[0]:
                        op14fields.update(first)

                        findChannel = self.findVisibleChannels(guildID, types="all", findFirst=True, token=token)
                        if findChannel:
                            op14fields["channel_ranges"] = {findChannel[0]: [[0,99]]}
                else:
                        op14fields.update(rest)
                        findChannel = self.findVisibleChannels(guildID, types="all", findFirst=True, token=token)
                        if findChannel:
                            op14fields["channel_ranges"] = {findChannel[0]: [[0,99]]}
                #sending the request
                if wait: time.sleep(wait)
                self.gatewayobj.memberFetchingStatus["first"].append(guildID)
                self.gatewayobj.request.lazyGuild(**op14fields)

    #helper for searchGuildMembers
    def handleGuildMemberSearches(self, resp, guildIDs, saveAsQuery, isQueryOverridden, userIDs, keep): #hm what happens if all userIDs are found? well good news: "not_found" value is just []
        if resp.event.guild_members_chunk:
            chunk = resp.parsed.auto()
            gID = chunk["guild_id"]
            match = False
            if gID in guildIDs:
                if userIDs and "not_found" in chunk:
                    match = True
                    for member in chunk["members"]:
                        member_id, member_properties = self.reformat_member(member, keep=keep)
                        self.gatewayobj.guildMemberSearches[gID]["ids"].add(member_id)
                        self.gatewayobj.session.guild(gID).updateOneMember(member_id, member_properties)
                elif not userIDs:
                    if isQueryOverridden:
                        match = True #no checks
                        for member in chunk["members"]:
                            member_id, member_properties = self.reformat_member(member, keep=keep)
                            self.gatewayobj.guildMemberSearches[gID]["queries"][saveAsQuery].add(member_id)
                            self.gatewayobj.session.guild(gID).updateOneMember(member_id, member_properties)
                    else: #check results
                        if all([(re.sub(' +', ' ', k["user"]["username"].lower()).startswith(saveAsQuery) or re.sub(' +', ' ', k["nick"].lower()).startswith(saveAsQuery)) if k.get('nick') else re.sub(' +', ' ', k["user"]["username"].lower()).startswith(saveAsQuery) for k in chunk["members"]]): #search user/nick, ignore case, replace consecutive spaces with 1 space
                            match = True
                            for member in chunk["members"]:
                                member_id, member_properties = self.reformat_member(member, keep=keep)
                                self.gatewayobj.guildMemberSearches[gID]["queries"][saveAsQuery].add(member_id)
                                self.gatewayobj.session.guild(gID).updateOneMember(member_id, member_properties)
                if chunk["chunk_index"] == chunk["chunk_count"]-1 and gID==guildIDs[-1]: #if at end
                    if match:
                        self.gatewayobj.removeCommand(
                            {
                                "function": self.handleGuildMemberSearches,
                                "params": {
                                    "guildIDs": guildIDs,
                                    "saveAsQuery": saveAsQuery,
                                    "isQueryOverridden": isQueryOverridden,
                                    "userIDs": userIDs, 
                                    "keep": keep
                                },
                            }
                        )

    def searchGuildMembers(self, guildIDs, query, saveAsQueryOverride, limit, presences, userIDs, keep):
        if self.gatewayobj.READY:
            saveAsQuery = query.lower() if saveAsQueryOverride==None else saveAsQueryOverride.lower()
            #create a spot to put the data in bot.gateway.guildMemberSearches
            if userIDs: #userID storage
                for i in guildIDs:
                    if i not in self.gatewayobj.guildMemberSearches:
                        self.gatewayobj.guildMemberSearches[i] = {"ids":set()}
                    if "ids" not in self.gatewayobj.guildMemberSearches[i]:
                        self.gatewayobj.guildMemberSearches[i]["ids"] = set()
            else: #query storage (saveAsQuery)
                for k in guildIDs:
                    if k not in self.gatewayobj.guildMemberSearches:
                        self.gatewayobj.guildMemberSearches[k] = {"queries":{}}
                    if "queries" not in self.gatewayobj.guildMemberSearches[k]:
                        self.gatewayobj.guildMemberSearches[k]["queries"] = {}
                    if saveAsQuery not in self.gatewayobj.guildMemberSearches[k]["queries"]:
                        self.gatewayobj.guildMemberSearches[k]["queries"][saveAsQuery] = set()
            self.gatewayobj.command(
                {
                    "function": self.handleGuildMemberSearches,
                    "priority": 0,
                    "params": {
                        "guildIDs": guildIDs,
                        "saveAsQuery": saveAsQuery,
                        "isQueryOverridden": saveAsQueryOverride != None,
                        "userIDs": userIDs,
                        "keep": keep,
                    },
                }
            )
            self.gatewayobj.request.searchGuildMembers(guildIDs, query, limit, presences, userIDs)
